class ISAAC {
    constructor() {
        // Initialize instance variables
        this.ccount = 0;  
        this.rsl = new Array(256); 
        this.mm = new Array(256);   
        this.aa = 0; 
        this.bb = 0; 
        this.cc = 0; 
        this.initialize(); 
    }

    initialize() {
        
        for (let i = 0; i < 256; i++) {
            this.rsl[i] = 0;
            this.mm[i] = 0;
        }
        this.randinit(); 
    }

    mix() {
        
        let a = this.aa;
        let b = this.bb;
        let c = this.cc;
        let d = 0, e = 0, f = 0, g = 0, h = 0;

        a ^= b << 11; d += a; b += c;
        b ^= c >>> 2; e += b; c += d;
        c ^= d << 8; f += c; d += e;
        d ^= e >>> 16; g += d; e += f;
        e ^= f << 10; h += e; f += g;
        f ^= g >>> 4; a += f; g += h;
        g ^= h << 8; b += g; h += a;
        h ^= a >>> 9; c += h; a += b;

       
        this.aa = a;
        this.bb = b;
        this.cc = c;
    }

    randinit() {
        const goldenRatio = 0x9e3779b9;
        let a = goldenRatio, b = goldenRatio, c = goldenRatio, d = goldenRatio;
        let e = goldenRatio, f = goldenRatio, g = goldenRatio, h = goldenRatio;

        
        for (let i = 0; i < 4; i++) this.mix();

        
        for (let i = 0; i < 256; i += 8) {
            a += this.rsl[i  ]; b += this.rsl[i+1]; c += this.rsl[i+2]; d += this.rsl[i+3];
            e += this.rsl[i+4]; f += this.rsl[i+5]; g += this.rsl[i+6]; h += this.rsl[i+7];

            this.mix();

            this.mm[i  ] = a >>> 0; this.mm[i+1] = b >>> 0; this.mm[i+2] = c >>> 0; this.mm[i+3] = d >>> 0;
            this.mm[i+4] = e >>> 0; this.mm[i+5] = f >>> 0; this.mm[i+6] = g >>> 0; this.mm[i+7] = h >>> 0;
        }

        
        for (let i = 0; i < 256; i += 8) {
            a += this.mm[i  ]; b += this.mm[i+1]; c += this.mm[i+2]; d += this.mm[i+3];
            e += this.mm[i+4]; f += this.mm[i+5]; g += this.mm[i+6]; h += this.mm[i+7];

            this.mix();

            this.mm[i  ] = a >>> 0; this.mm[i+1] = b >>> 0; this.mm[i+2] = c >>> 0; this.mm[i+3] = d >>> 0;
            this.mm[i+4] = e >>> 0; this.mm[i+5] = f >>> 0; this.mm[i+6] = g >>> 0; this.mm[i+7] = h >>> 0;
        }

        this.isaac(); 
    }

    isaac() {
        this.cc = (this.cc + 1) >>> 0;
        this.bb = (this.bb + this.cc) >>> 0;

        for (let i = 0; i < 256; i++) {
            let x = this.mm[i];
            switch (i % 4) {
                case 0: this.aa ^= (this.aa << 13); break;
                case 1: this.aa ^= (this.aa >>> 6); break;
                case 2: this.aa ^= (this.aa << 2); break;
                case 3: this.aa ^= (this.aa >>> 16); break;
            }
            this.aa = (this.aa + this.mm[(i + 128) % 256]) >>> 0;
            let y = (this.mm[(x >>> 2) % 256] + this.aa + this.bb) >>> 0;
            this.mm[i] = y >>> 0;
            this.bb = (this.mm[(y >>> 10) % 256] + x) >>> 0;
            this.rsl[i] = this.bb >>> 0;
        }
    }

    rand() {
        if (this.ccount === 0) {
            this.isaac(); 
            this.ccount = 256; 
        }
        return this.rsl[--this.ccount] >>> 0;
    }

    seed(arr) {
        for (let i = 0; i < arr.length; i++) {
            if (arr[i] === 0) {
				
                this.mix(); 
            } else {
				
                this.isaac(); 
            }
        }
    }
}

function simpleHash(input) {
    const binaryString = decompose(input);
    const binaryArray = binaryStringToArray(binaryString);

    const isaac = new ISAAC();
	isaac.randinit();
	isaac.seed(binaryStringToArray(decompose('730699cc008452b327fe4b5605900d0fab5b6c14290c12c2d77fd9543d2771a6')));
    isaac.seed(binaryArray);

    let hash = '';
    for (let i = 0; i < 5; i++) {
        const randNum = isaac.rand();
        const hexRandNum = randNum.toString(16).padStart(8, '0');
        hash += hexRandNum;
    }

    return hash;
}

function decompose(str) {
    let binaryString = '';
    for (let i = 0; i < str.length; i++) {
        let unicodeValue = str.charCodeAt(i);
        let binaryValue = unicodeValue.toString(2).padStart(16, '0'); 
        binaryString += binaryValue;
    }
    return binaryString;
}

function binaryStringToArray(binaryString) {
    return binaryString.split('').map(char => parseInt(char, 10));
}

